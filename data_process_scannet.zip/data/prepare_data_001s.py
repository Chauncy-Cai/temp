'''
Modified from SparseConvNet data preparation: https://github.com/facebookresearch/SparseConvNet/blob/master/examples/ScanNet/prepare_data.py
'''

import glob, plyfile, numpy as np, multiprocessing as mp, torch, json, argparse

import scannet_util,os,csv,random

from warnings import simplefilter
simplefilter(action='ignore', category=FutureWarning)

# Map relevant classes to {0,1,...,19}, and ignored classes to -100
remapper = np.ones(150) * (-100)
for i, x in enumerate([1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 14, 16, 24, 28, 33, 34, 36, 39]):
    remapper[x] = i

parser = argparse.ArgumentParser()
parser.add_argument('--data_split', help='data split (train / val / test)', default='train')
opt = parser.parse_args()

split = opt.data_split
print('data split: {}'.format(split))
files = sorted(glob.glob('/mntntfs/med_data1/yushuang/bcm_share/ScanNet/scans/scene*_*/*_vh_clean_2.ply'))
print('all files: ', len(files))

eval_split = [line.rstrip() for line in open('/mntntfs/med_data1/yushuang/bcm_share/ScanNet/meta_data/scannetv2_val.txt')]
files_train = []
for file in files:
    flag_eval = 0
    for scene_name in eval_split:
        if scene_name in file:
            flag_eval = 1
            break
    if not flag_eval:
        files_train += [file]
print('train files: ', len(files_train))

path_root = "/data/yushuang/Data/ScanNet/"
path_root_obj = "/mntntfs/med_data1/yushuang/scannet_processed/"

dic={}
dic['wall']=0
dic['floor']=1
dic['cabinet']=2 #
dic['bed']=3
dic['chair']=4
dic['sofa']=5
dic['table']=6 ##
dic['door']=7 ##
dic['window']=8 #
dic['bookshelf']=9
dic['picture']=10 ###
dic['counter']=11 ###
dic['desk']=12 ##
dic['curtain']=13
dic['refridgerator']=14 #
dic['shower curtain']=15
dic['toilet']=16
dic['sink']=17 #
dic['bathtub']=18
dic['otherfurniture']=19 ##

name2label={}
with open("scannetv2-labels.combined.tsv") as fd:
    rd = csv.reader(fd, delimiter="\t", quotechar='"')
    start=1
    for row in rd:
        if start==1:
           start=0
           continue
        key=row[1]
        value=row[7]
        if value not in dic.keys():
            continue
        name2label[key]=value
        #print (key,value,dic[value])

folders = ['train_unsup/']
scenes_train = list(os.listdir(path_root + folders[0]))
scenes_path  = {}
for scene in scenes_train:
    scene = scene[:12]
    scenes_path[scene] = (path_root + folders[0] + scene + '_vh_clean_2.ply_inst_nostuff.pth', 
                          path_root_obj + 'train_base/' + scene + '_vh_clean_2.ply_inst_nostuff.pth')

def f(fn):
    name=fn.split('/')[-1]
    #if os.path.exists('train/'+name+'_inst_nostuff.pth'):
    #    return

    fn2 = fn[:-3] + 'labels.ply'
    fn3 = fn[:-15] + '_vh_clean_2.0.010000.segs.json'
    fn4 = fn[:-15] + '.aggregation.json'
    # print(fn)

    f = plyfile.PlyData().read(fn)
    points = np.array([list(x) for x in f.elements[0]])
    coords = np.ascontiguousarray(points[:, :3] - points[:, :3].mean(0))
    colors = np.ascontiguousarray(points[:, 3:6]) / 127.5 - 1

    f2 = plyfile.PlyData().read(fn2)
    sem_labels = remapper[np.array(f2.elements[0]['label'])]

    ################# get objects and segments from other files #################

    scene_name = fn.split('/')[-2]
    scene_path = scenes_path[scene_name]
    _, _, _, _, seg = torch.load(scene_path[0])
    # _, _, _, objects = torch.load(scene_path[1])

    ################# give labels to each superpoint #################
    room_labels_super = np.zeros(sem_labels.shape) - 100

    import random
    sampled_idx = random.sample(list(range(sem_labels.shape[0])), int(sem_labels.shape[0]*0.001))
    label_masked = np.zeros(sem_labels.shape) - 100
    label_masked[sampled_idx] = sem_labels[sampled_idx]

    for super_idx in set(seg):
        super_indices = np.where(seg == super_idx)
        # inst_onept_idx = random.choice(list(instance_indices[0]))
        labeled_indices = np.where(label_masked[super_indices] >= 0)
        if labeled_indices[0].shape[0] != 0:
            label_indices = super_indices[0][labeled_indices].tolist()
            label_idx = random.choice(label_indices)
            room_labels_super[super_indices] = label_masked[label_idx]
        else:
            pass
    print(np.where(label_masked>=0)[0].shape, np.where(room_labels_super>=0)[0].shape, label_masked.shape)

    #################

    ##### torch.save((coords, colors, sem_labels, groups, seg), 'train_weakly/'+name+'_inst_nostuff.pth')
    torch.save((coords, colors, room_labels_super, 0, seg), path_root+'train_001s/'+name+'_inst_nostuff.pth')
    # print(groups)
    print('Saving to ' + fn[:-15]+'_inst_nostuff.pth')

# for fn in files:
#     f(fn)

p = mp.Pool(processes=mp.cpu_count())
p.map(f, files_train)
p.close()
p.join()
