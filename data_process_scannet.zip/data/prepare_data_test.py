'''
Modified from SparseConvNet data preparation: https://github.com/facebookresearch/SparseConvNet/blob/master/examples/ScanNet/prepare_data.py
'''

import glob, plyfile, numpy as np, multiprocessing as mp, torch, json, argparse

import scannet_util,os,csv

parser = argparse.ArgumentParser()
parser.add_argument('--data_split', help='data split (train / val / test)', default='train')
opt = parser.parse_args()

split = opt.data_split
print('data split: {}'.format(split))
files = sorted(glob.glob('/mntntfs/med_data1/yushuang/bcm_share/ScanNet/scans_test/scene*_*/*_vh_clean_2.ply'))

print(len(files))

path_root = "/mntntfs/med_data1/yushuang/bcm_share/OTOC/data/scannet/"

def f(fn):
    name = fn.split('/')[-1][:12]
    #if os.path.exists('train/'+name+'_inst_nostuff.pth'):
    #    return
    print(fn)

    f = plyfile.PlyData().read(fn)
    points = np.array([list(x) for x in f.elements[0]])
    coords = np.ascontiguousarray(points[:, :3] - points[:, :3].mean(0))
    colors = np.ascontiguousarray(points[:, 3:6]) / 127.5 - 1

    torch.save((coords, colors), path_root+'test_base/'+name+'.pth')
    print('Saving to ' + fn[:12]+'.pth')

# for fn in files:
#     f(fn)

p = mp.Pool(processes=mp.cpu_count())
p.map(f, files)
p.close()
p.join()
