import os
import shutil

path_old = '/mntntfs/med_data1/yushuang/bcm_share/OTOC/data/scannet/train_object/'
path_new = '/mntntfs/med_data1/yushuang/bcm_share/OTOC/data/scannet/eval_object/'
eval_split = [line.rstrip() for line in open('/mntntfs/med_data1/yushuang/bcm_share/ScanNet/meta_data/scannetv2_val.txt')]

for scene_name in eval_split:
    scene_name = scene_name + '_vh_clean_2.ply_inst_nostuff.pth'
    shutil.move(path_old+scene_name, path_new)